"""Phase-one LiteLLM gateway embedded in FastAPI."""
